const express = require("express");
const db = require("../db");
const { v4: uuidv4 } = require("uuid");
const { requireAuth, requireModule, blockLectureSeule } = require("../middleware/auth");
const { t } = require("../utils/i18n");
const { assurerTiersPourFournisseurSilencieux } = require("../services/comptaService");
const echeancier = require("../services/echeancier");

const router = express.Router();
router.use(requireAuth);
router.use(requireModule("fournisseurs"));
router.use(blockLectureSeule);

/**
 * Recalcule le score de fiabilite d'un fournisseur (Module 15) a partir de
 * son historique d'offres pour ce tenant : proportion d'offres retenues
 * parmi toutes celles soumises. Heuristique simple documentee comme telle -
 * a affiner si un suivi de performance plus riche est ajoute au schema.
 */
async function recalculerScoreFiabilite(fournisseurId) {
  const stats = await db.query(
    `SELECT
       COUNT(*)::int AS total,
       COUNT(*) FILTER (WHERE retenue = true)::int AS retenues
     FROM offre_fournisseur
     WHERE fournisseur_id = $1`,
    [fournisseurId]
  );
  const { total, retenues } = stats.rows[0];
  const score = total > 0 ? Math.round((retenues / total) * 100 * 100) / 100 : null;

  await db.query(`UPDATE fournisseur SET score_fiabilite = $1 WHERE id = $2`, [score, fournisseurId]);
  return score;
}

// ----------------------------------------------------------------------------
// Fournisseurs (tenant-scope)
// ----------------------------------------------------------------------------

// GET /api/fournisseurs
router.get("/", async (req, res) => {
  try {
    const result = await db.query(
      `SELECT * FROM fournisseur WHERE tenant_id = $1 ORDER BY nom ASC`,
      [req.user.tenantId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: t(req, "FOURNISSEURS_FETCH_ERROR") });
  }
});

// POST /api/fournisseurs
router.post("/", async (req, res) => {
  const { nom, pays } = req.body;
  if (!nom) {
    return res.status(400).json({ error: t(req, "FOURNISSEUR_NOM_REQUIRED") });
  }
  // Conditions de paiement du fournisseur : obligatoires a la creation.
  const ech = echeancier.normaliser(req.body.echeancier);
  if (ech.erreur) return res.status(400).json({ error: t(req, ech.erreur) });
  try {
    const result = await db.query(
      `INSERT INTO fournisseur (id, tenant_id, nom, pays, echeancier_json) VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [uuidv4(), req.user.tenantId, nom, pays || null, JSON.stringify(ech.lignes)]
    );
    await assurerTiersPourFournisseurSilencieux(req.user.tenantId, result.rows[0]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: t(req, "FOURNISSEUR_CREATE_ERROR") });
  }
});

// PATCH /api/fournisseurs/:id : nom, pays, coordonnees (bon de commande) et/ou conditions de paiement (echeancier).
router.patch("/:id", async (req, res) => {
  const { id } = req.params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return res.status(404).json({ error: t(req, "FOURNISSEUR_NOT_FOUND") });
  const b = req.body || {};
  let echJson = null;
  if (b.echeancier !== undefined) {
    const ech = echeancier.normaliser(b.echeancier);
    if (ech.erreur) return res.status(400).json({ error: t(req, ech.erreur) });
    echJson = JSON.stringify(ech.lignes);
  }
  if (b.nom !== undefined && !String(b.nom).trim()) return res.status(400).json({ error: t(req, "FOURNISSEUR_NOM_REQUIRED") });
  const txt = (v, max) => String(v || "").trim().slice(0, max) || null;
  try {
    const r = await db.query(
      `UPDATE fournisseur SET nom = COALESCE($1, nom), pays = CASE WHEN $2::boolean THEN $3 ELSE pays END,
              echeancier_json = COALESCE($4::jsonb, echeancier_json),
              adresse = CASE WHEN $7::boolean THEN $8 ELSE adresse END,
              email = CASE WHEN $9::boolean THEN $10 ELSE email END,
              telephone = CASE WHEN $11::boolean THEN $12 ELSE telephone END,
              contact_nom = CASE WHEN $13::boolean THEN $14 ELSE contact_nom END
       WHERE id = $5 AND tenant_id = $6 RETURNING *`,
      [b.nom !== undefined ? String(b.nom).trim() : null, b.pays !== undefined, b.pays || null, echJson, id, req.user.tenantId,
       b.adresse !== undefined, txt(b.adresse, 300), b.email !== undefined, txt(b.email, 160),
       b.telephone !== undefined, txt(b.telephone, 60), b.contact_nom !== undefined, txt(b.contact_nom, 120)]
    );
    if (!r.rows[0]) return res.status(404).json({ error: t(req, "FOURNISSEUR_NOT_FOUND") });
    res.json(r.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: t(req, "FOURNISSEUR_UPDATE_ERROR") });
  }
});

// ----------------------------------------------------------------------------
// Offres fournisseurs (par dossier)
// ----------------------------------------------------------------------------

// GET /api/fournisseurs/dossiers/:dossierId/offres
router.get("/dossiers/:dossierId/offres", async (req, res) => {
  const { dossierId } = req.params;
  try {
    const dossierCheck = await db.query(
      `SELECT id FROM dossier_ao WHERE id = $1 AND tenant_id = $2`,
      [dossierId, req.user.tenantId]
    );
    if (dossierCheck.rows.length === 0) {
      return res.status(404).json({ error: t(req, "DOSSIER_NOT_FOUND") });
    }

    const result = await db.query(
      `SELECT o.*, f.nom AS fournisseur_nom, f.pays AS fournisseur_pays, f.score_fiabilite,
              inc.code AS incoterm_code
       FROM offre_fournisseur o
       JOIN fournisseur f ON f.id = o.fournisseur_id
       LEFT JOIN incoterm_scenario inc ON inc.id = o.incoterm_scenario_id
       WHERE o.dossier_ao_id = $1
       ORDER BY o.prix_exw ASC NULLS LAST`,
      [dossierId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: t(req, "OFFRES_FETCH_ERROR") });
  }
});

// POST /api/fournisseurs/dossiers/:dossierId/offres
router.post("/dossiers/:dossierId/offres", async (req, res) => {
  // Lot 6 : ancien comparateur en lecture seule, les offres se saisissent dans le Dossier de calcul.
  return res.status(409).json({ error: t(req, "OFFRE_LEGACY_READONLY") });
  // eslint-disable-next-line no-unreachable
  const { dossierId } = req.params;
  const {
    fournisseur_id,
    prix_exw,
    devise,
    delai_jours,
    delai_paiement_jours,
    condition_reglement,
    pourcentage_acompte,
    incoterm_scenario_id,
  } = req.body;

  if (!fournisseur_id) {
    return res.status(400).json({ error: t(req, "FOURNISSEUR_ID_REQUIRED") });
  }

  try {
    const dossierCheck = await db.query(
      `SELECT id FROM dossier_ao WHERE id = $1 AND tenant_id = $2`,
      [dossierId, req.user.tenantId]
    );
    if (dossierCheck.rows.length === 0) {
      return res.status(404).json({ error: t(req, "DOSSIER_NOT_FOUND") });
    }

    const fournisseurCheck = await db.query(
      `SELECT id FROM fournisseur WHERE id = $1 AND tenant_id = $2`,
      [fournisseur_id, req.user.tenantId]
    );
    if (fournisseurCheck.rows.length === 0) {
      return res.status(404).json({ error: t(req, "FOURNISSEUR_NOT_FOUND") });
    }

    const inserted = await db.query(
      `INSERT INTO offre_fournisseur
         (id, dossier_ao_id, fournisseur_id, prix_exw, devise, delai_jours, delai_paiement_jours,
          condition_reglement, pourcentage_acompte, incoterm_scenario_id)
       VALUES ($1, $2, $3, $4, COALESCE($5, 'XOF'), $6, $7, $8, $9, $10)
       RETURNING id`,
      [
        uuidv4(),
        dossierId,
        fournisseur_id,
        prix_exw || null,
        devise || null,
        delai_jours || null,
        delai_paiement_jours || null,
        condition_reglement || null,
        pourcentage_acompte || null,
        incoterm_scenario_id || null,
      ]
    );

    await recalculerScoreFiabilite(fournisseur_id);

    // On renvoie la ligne enrichie (nom fournisseur, score, code incoterm)
    // plutot que la ligne brute, pour que le front n'ait pas besoin de
    // recharger toute la liste pour afficher ces informations.
    const result = await db.query(
      `SELECT o.*, f.nom AS fournisseur_nom, f.pays AS fournisseur_pays, f.score_fiabilite,
              inc.code AS incoterm_code
       FROM offre_fournisseur o
       JOIN fournisseur f ON f.id = o.fournisseur_id
       LEFT JOIN incoterm_scenario inc ON inc.id = o.incoterm_scenario_id
       WHERE o.id = $1`,
      [inserted.rows[0].id]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: t(req, "OFFRE_CREATE_ERROR") });
  }
});

// PATCH /api/fournisseurs/offres/:id/retenue - retient une offre (et
// desactive automatiquement les autres offres du meme dossier, puisqu'un
// seul fournisseur est normalement retenu par besoin).
router.patch("/offres/:id/retenue", async (req, res) => {
  return res.status(409).json({ error: t(req, "OFFRE_LEGACY_READONLY") });
  // eslint-disable-next-line no-unreachable
  const { id } = req.params;
  try {
    const offreResult = await db.query(
      `SELECT o.*, d.tenant_id FROM offre_fournisseur o
       JOIN dossier_ao d ON d.id = o.dossier_ao_id
       WHERE o.id = $1 AND d.tenant_id = $2`,
      [id, req.user.tenantId]
    );
    if (offreResult.rows.length === 0) {
      return res.status(404).json({ error: t(req, "OFFRE_NOT_FOUND") });
    }
    const offre = offreResult.rows[0];

    await db.query(
      `UPDATE offre_fournisseur SET retenue = false WHERE dossier_ao_id = $1`,
      [offre.dossier_ao_id]
    );
    const result = await db.query(
      `UPDATE offre_fournisseur SET retenue = true WHERE id = $1 RETURNING *`,
      [id]
    );

    // Le score de tous les fournisseurs ayant soumissionne sur ce dossier
    // peut changer (celui retenu monte, ceux desormais non-retenus baissent).
    const fournisseursDuDossier = await db.query(
      `SELECT DISTINCT fournisseur_id FROM offre_fournisseur WHERE dossier_ao_id = $1`,
      [offre.dossier_ao_id]
    );
    for (const row of fournisseursDuDossier.rows) {
      await recalculerScoreFiabilite(row.fournisseur_id);
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: t(req, "OFFRE_RETENUE_ERROR") });
  }
});

module.exports = router;
