"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { api } from "../../../lib/api";
import { useLangue } from "../../../lib/i18n/LanguageContext";
import AppShell from "../../../lib/components/AppShell";

// Definit, pour chaque cle de tenant.parametres_calcul_prix_json (voir
// CLES_PARAMETRES_CALCUL_PRIX cote backend, routes/parametres.js), comment
// l'afficher/la saisir : "pourcentage" est stocke en decimal (0.20) mais
// saisi/affiche en pourcentage brut (20) - meme convention que le taux de
// TVA Ventes ci-dessus - tandis que "montant" (XOF) et "nombre" (parite de
// change) sont des valeurs brutes, pas des taux, et ne subissent aucune
// conversion.
const PARAM_DEFS_CALCUL_PRIX = [
  { cle: "tauxDroitDouane", labelKey: "calcPrixTauxDroitDouaneLabel", type: "pourcentage" },
  { cle: "tauxRedevanceStatistique", labelKey: "calcPrixTauxRedevanceStatistiqueLabel", type: "pourcentage" },
  { cle: "tauxPCS", labelKey: "calcPrixTauxPCSLabel", type: "pourcentage" },
  { cle: "tauxPCC", labelKey: "calcPrixTauxPCCLabel", type: "pourcentage" },
  { cle: "tauxCOSEC", labelKey: "calcPrixTauxCOSECLabel", type: "pourcentage" },
  { cle: "tauxTvaImport", labelKey: "calcPrixTauxTvaImportLabel", type: "pourcentage" },
  { cle: "tauxAssuranceFret", labelKey: "calcPrixTauxAssuranceFretLabel", type: "pourcentage" },
  { cle: "margeCibleDefaut", labelKey: "calcPrixMargeCibleDefautLabel", type: "pourcentage" },
  { cle: "pariteEurXof", labelKey: "calcPrixPariteEurXofLabel", type: "nombre" },
  { cle: "tauxCommissionTTHU", labelKey: "calcPrixTauxCommissionTTHULabel", type: "pourcentage" },
  { cle: "tauxCommissionDBS", labelKey: "calcPrixTauxCommissionDBSLabel", type: "pourcentage" },
  { cle: "commissionDbsMinimum", labelKey: "calcPrixCommissionDbsMinimumLabel", type: "montant" },
  { cle: "tauxTAF", labelKey: "calcPrixTauxTAFLabel", type: "pourcentage" },
  { cle: "forfaitSwift", labelKey: "calcPrixForfaitSwiftLabel", type: "montant" },
  { cle: "forfaitTimbre", labelKey: "calcPrixForfaitTimbreLabel", type: "montant" },
  { cle: "forfaitAutresFraisVirement", labelKey: "calcPrixForfaitAutresFraisVirementLabel", type: "montant" },
  { cle: "tauxAutresFraisVirement", labelKey: "calcPrixTauxAutresFraisVirementLabel", type: "pourcentage" },
  { cle: "refacturerFraisPaiement", labelKey: "calcPrixRefacturerFraisPaiementLabel", type: "case" },
];

export default function EnteteSettingsPage() {
  const { t } = useLangue();
  const [form, setForm] = useState({
    raison_sociale: "",
    adresse: "",
    telephone: "",
    email: "",
    signataire_nom: "",
    signataire_titre: "",
    rccm: "",
    ninea: "",
    site_web: "",
    coordonnees_bancaires: "",
  });
  const [chargement, setChargement] = useState(true);
  const [enregistrement, setEnregistrement] = useState(false);
  const [confirmation, setConfirmation] = useState(false);
  const [erreur, setErreur] = useState("");

  // Parametres du module Ventes : taux de TVA systematique + logo, utilises
  // automatiquement sur chaque devis/facture genere (voir routes/ventes.js
  // cote backend). Regroupes sur cette meme page d'en-tete de structure :
  // ce sont les memes informations d'identite de l'entreprise.
  const [tauxTva, setTauxTva] = useState("18");
  const [logo, setLogo] = useState(null);
  const [enregistrementTva, setEnregistrementTva] = useState(false);
  const [confirmationTva, setConfirmationTva] = useState(false);
  const [televersementLogo, setTeleversementLogo] = useState(false);
  const inputLogoRef = useRef(null);
  const [signatureCachet, setSignatureCachet] = useState(null);
  const [televersementSignatureCachet, setTeleversementSignatureCachet] = useState(false);
  const inputSignatureCachetRef = useRef(null);

  // Reprise de numerotation (Devis / Facture-BL) : permet de renseigner le
  // dernier numero deja utilise ailleurs (Excel, etc.) pour l'annee en cours
  // (voir GET/PATCH /api/parametres/numerotation cote backend).
  const [numerotation, setNumerotation] = useState({ dernier_numero_devis: "0", dernier_numero_vente: "0" });
  const [enregistrementNumerotation, setEnregistrementNumerotation] = useState(false);
  const [confirmationNumerotation, setConfirmationNumerotation] = useState(false);

  // Parametres du Dossier de calcul (prix de revient et marge) - stockes en
  // saisie brute (chaines) pour permettre un champ vide pendant la frappe,
  // convertis en nombre uniquement a l'enregistrement (meme approche que
  // formMarge plus bas dans la page dossier detail).
  const [formCalculPrix, setFormCalculPrix] = useState({});
  // Profil d'activite du client (MARCHES | NEGOCE | LES_DEUX, migration 068) : adapte menu et libelles.
  const [profilActivite, setProfilActivite] = useState("LES_DEUX");
  const [enregistrementCalculPrix, setEnregistrementCalculPrix] = useState(false);
  const [confirmationCalculPrix, setConfirmationCalculPrix] = useState(false);

  useEffect(() => {
    api
      .getEntete()
      .then((data) =>
        setForm({
          raison_sociale: data.raison_sociale || "",
          adresse: data.adresse || "",
          telephone: data.telephone || "",
          email: data.email || "",
          signataire_nom: data.signataire_nom || "",
          signataire_titre: data.signataire_titre || "",
          rccm: data.rccm || "",
          ninea: data.ninea || "",
          site_web: data.site_web || "",
          coordonnees_bancaires: data.coordonnees_bancaires || "",
        })
      )
      .catch((err) => setErreur(err.message))
      .finally(() => setChargement(false));

    api
      .getParametresVentes()
      .then((data) => {
        setTauxTva(String(data.taux_tva_pourcentage));
        setLogo(data.logo_base64 ? { base64: data.logo_base64, mime: data.logo_type_mime } : null);
        setSignatureCachet(
          data.signature_cachet_base64
            ? { base64: data.signature_cachet_base64, mime: data.signature_cachet_type_mime }
            : null
        );
      })
      .catch(() => {});

    api
      .getProfilActivite()
      .then((d) => setProfilActivite(d.profil_activite || "LES_DEUX"))
      .catch(() => {});

    api
      .getParametresCalculPrix()
      .then((data) => {
        const valeurs = {};
        PARAM_DEFS_CALCUL_PRIX.forEach(({ cle, type }) => {
          const brut = Number(data[cle]) || 0;
          valeurs[cle] = String(type === "pourcentage" ? brut * 100 : type === "case" ? (brut === 1 ? 1 : 0) : brut);
        });
        setFormCalculPrix(valeurs);
      })
      .catch(() => {});

    api
      .getNumerotation()
      .then((data) =>
        setNumerotation({
          dernier_numero_devis: String(data.dernier_numero_devis),
          dernier_numero_vente: String(data.dernier_numero_vente),
        })
      )
      .catch(() => {});
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setEnregistrement(true);
    setConfirmation(false);
    try {
      await api.updateEntete(form);
      setConfirmation(true);
      setTimeout(() => setConfirmation(false), 2500);
    } catch (err) {
      setErreur(err.message);
    } finally {
      setEnregistrement(false);
    }
  }

  async function handleEnregistrerTva(e) {
    e.preventDefault();
    setEnregistrementTva(true);
    setConfirmationTva(false);
    setErreur("");
    try {
      await api.patchParametresVentes({ taux_tva_pourcentage: Number(tauxTva) });
      setConfirmationTva(true);
      setTimeout(() => setConfirmationTva(false), 2500);
    } catch (err) {
      setErreur(err.message);
    } finally {
      setEnregistrementTva(false);
    }
  }

  async function handleChangerProfil(valeur) {
    const ancien = profilActivite;
    setProfilActivite(valeur);
    setErreur("");
    try {
      await api.patchProfilActivite(valeur);
      // Le menu est construit au chargement : on recharge la page pour l'appliquer tout de suite.
      window.location.reload();
    } catch (err) {
      setProfilActivite(ancien);
      setErreur(err.message);
    }
  }

  async function handleEnregistrerCalculPrix(e) {
    e.preventDefault();
    setEnregistrementCalculPrix(true);
    setConfirmationCalculPrix(false);
    setErreur("");
    try {
      const payload = {};
      PARAM_DEFS_CALCUL_PRIX.forEach(({ cle, type }) => {
        const saisi = Number(formCalculPrix[cle]);
        payload[cle] = type === "pourcentage" ? saisi / 100 : type === "case" ? (saisi === 1 ? 1 : 0) : saisi;
      });
      await api.patchParametresCalculPrix(payload);
      setConfirmationCalculPrix(true);
      setTimeout(() => setConfirmationCalculPrix(false), 2500);
    } catch (err) {
      setErreur(err.message);
    } finally {
      setEnregistrementCalculPrix(false);
    }
  }

  async function handleEnregistrerNumerotation(e) {
    e.preventDefault();
    setEnregistrementNumerotation(true);
    setConfirmationNumerotation(false);
    setErreur("");
    try {
      await api.patchNumerotation({
        dernier_numero_devis: Number(numerotation.dernier_numero_devis),
        dernier_numero_vente: Number(numerotation.dernier_numero_vente),
      });
      setConfirmationNumerotation(true);
      setTimeout(() => setConfirmationNumerotation(false), 2500);
    } catch (err) {
      setErreur(err.message);
    } finally {
      setEnregistrementNumerotation(false);
    }
  }

  async function handleChoisirLogo(e) {
    const fichier = e.target.files?.[0];
    if (!fichier) return;
    setTeleversementLogo(true);
    setErreur("");
    try {
      const maj = await api.uploaderLogoVentes(fichier);
      setLogo(maj.logo_base64 ? { base64: maj.logo_base64, mime: maj.logo_type_mime } : null);
    } catch (err) {
      setErreur(err.message);
    } finally {
      setTeleversementLogo(false);
      if (inputLogoRef.current) inputLogoRef.current.value = "";
    }
  }

  async function handleSupprimerLogo() {
    setTeleversementLogo(true);
    setErreur("");
    try {
      await api.supprimerLogoVentes();
      setLogo(null);
    } catch (err) {
      setErreur(err.message);
    } finally {
      setTeleversementLogo(false);
    }
  }

  async function handleChoisirSignatureCachet(e) {
    const fichier = e.target.files?.[0];
    if (!fichier) return;
    setTeleversementSignatureCachet(true);
    setErreur("");
    try {
      const maj = await api.uploaderSignatureCachetVentes(fichier);
      setSignatureCachet(maj.signature_cachet_base64 ? { base64: maj.signature_cachet_base64, mime: maj.signature_cachet_type_mime } : null);
    } catch (err) {
      setErreur(err.message);
    } finally {
      setTeleversementSignatureCachet(false);
      if (inputSignatureCachetRef.current) inputSignatureCachetRef.current.value = "";
    }
  }

  async function handleSupprimerSignatureCachet() {
    setTeleversementSignatureCachet(true);
    setErreur("");
    try {
      await api.supprimerSignatureCachetVentes();
      setSignatureCachet(null);
    } catch (err) {
      setErreur(err.message);
    } finally {
      setTeleversementSignatureCachet(false);
    }
  }

  return (
    <AppShell title={t("enteteTitle")}>
      <p style={{ fontSize: 12.5, color: "var(--sub)", marginBottom: 16 }}>{t("enteteDescription")}</p>

      {erreur && <p style={{ color: "var(--brique)", fontSize: 12.5, marginBottom: 14 }}>{erreur}</p>}

      {!chargement && (
        <form onSubmit={handleSubmit} className="card" style={{ maxWidth: 560 }}>
          <label style={labelStyle}>{t("raisonSocialeLabel")}</label>
          <input
            value={form.raison_sociale}
            onChange={(e) => setForm((f) => ({ ...f, raison_sociale: e.target.value }))}
            style={inputStyle}
          />

          <label style={{ ...labelStyle, marginTop: 12 }}>{t("adresseLabel")}</label>
          <input
            value={form.adresse}
            onChange={(e) => setForm((f) => ({ ...f, adresse: e.target.value }))}
            style={inputStyle}
          />

          <label style={{ ...labelStyle, marginTop: 12 }}>{t("telephoneLabel")}</label>
          <input
            value={form.telephone}
            onChange={(e) => setForm((f) => ({ ...f, telephone: e.target.value }))}
            style={inputStyle}
          />

          <label style={{ ...labelStyle, marginTop: 12 }}>{t("emailLabel2")}</label>
          <input
            type="email"
            value={form.email}
            onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            style={inputStyle}
          />

          <label style={{ ...labelStyle, marginTop: 12 }}>{t("signataireNomLabel")}</label>
          <input
            value={form.signataire_nom}
            onChange={(e) => setForm((f) => ({ ...f, signataire_nom: e.target.value }))}
            style={inputStyle}
          />

          <label style={{ ...labelStyle, marginTop: 12 }}>{t("signataireTitreLabel")}</label>
          <input
            value={form.signataire_titre}
            onChange={(e) => setForm((f) => ({ ...f, signataire_titre: e.target.value }))}
            style={inputStyle}
          />

          <h3 style={{ fontSize: 12.5, color: "var(--petrol)", marginTop: 20, marginBottom: 4 }}>
            {t("enteteFooterSection")}
          </h3>
          <p style={{ fontSize: 11, color: "var(--sub)", marginBottom: 10 }}>{t("enteteFooterDescription")}</p>

          <label style={labelStyle}>{t("enteteRccmLabel")}</label>
          <input
            value={form.rccm}
            onChange={(e) => setForm((f) => ({ ...f, rccm: e.target.value }))}
            style={inputStyle}
          />

          <label style={{ ...labelStyle, marginTop: 12 }}>{t("enteteNineaLabel")}</label>
          <input
            value={form.ninea}
            onChange={(e) => setForm((f) => ({ ...f, ninea: e.target.value }))}
            style={inputStyle}
          />

          <label style={{ ...labelStyle, marginTop: 12 }}>{t("enteteSiteWebLabel")}</label>
          <input
            value={form.site_web}
            onChange={(e) => setForm((f) => ({ ...f, site_web: e.target.value }))}
            style={inputStyle}
          />

          <label style={{ ...labelStyle, marginTop: 12 }}>{t("enteteCoordonneesBancairesLabel")}</label>
          <input
            value={form.coordonnees_bancaires}
            onChange={(e) => setForm((f) => ({ ...f, coordonnees_bancaires: e.target.value }))}
            style={inputStyle}
          />

          <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 16 }}>
            <button type="submit" disabled={enregistrement} style={boutonPrincipalStyle}>
              {t("save")}
            </button>
            {confirmation && (
              <span style={{ fontSize: 12.5, color: "var(--vert)" }}>{t("savedConfirmation")}</span>
            )}
          </div>
        </form>
      )}

      {!chargement && (
        <div className="card" style={{ maxWidth: 560, marginTop: 16 }}>
          <h3 style={{ fontSize: 13.5, color: "var(--petrol)", marginBottom: 4 }}>{t("venteParametresSection")}</h3>
          <p style={{ fontSize: 11.5, color: "var(--sub)", marginBottom: 14 }}>{t("venteParametresDescription")}</p>

          <label style={labelStyle}>{t("venteLogoLabel")}</label>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 16 }}>
            {logo ? (
              <img
                src={`data:${logo.mime};base64,${logo.base64}`}
                alt="logo"
                style={{ maxWidth: 100, maxHeight: 70, objectFit: "contain", border: "1px solid var(--line)", borderRadius: 8, padding: 4 }}
              />
            ) : (
              <span style={{ fontSize: 12, color: "var(--sub)" }}>{t("venteNoLogo")}</span>
            )}
            <div style={{ display: "flex", gap: 8 }}>
              <button
                type="button"
                onClick={() => inputLogoRef.current?.click()}
                disabled={televersementLogo}
                style={boutonSecondaireStyle}
              >
                {televersementLogo ? t("saCreating") : t("venteUploadLogoButton")}
              </button>
              {logo && (
                <button type="button" onClick={handleSupprimerLogo} disabled={televersementLogo} style={boutonSecondaireStyle}>
                  {t("venteRemoveLogoButton")}
                </button>
              )}
            </div>
            <input ref={inputLogoRef} type="file" accept="image/png,image/jpeg" onChange={handleChoisirLogo} style={{ display: "none" }} />
          </div>

          <label style={labelStyle}>{t("venteSignatureCachetLabel")}</label>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 16 }}>
            {signatureCachet ? (
              <img
                src={`data:${signatureCachet.mime};base64,${signatureCachet.base64}`}
                alt="signature et cachet"
                style={{ maxWidth: 120, maxHeight: 80, objectFit: "contain", border: "1px solid var(--line)", borderRadius: 8, padding: 4 }}
              />
            ) : (
              <span style={{ fontSize: 12, color: "var(--sub)" }}>{t("venteNoSignatureCachet")}</span>
            )}
            <div style={{ display: "flex", gap: 8 }}>
              <button
                type="button"
                onClick={() => inputSignatureCachetRef.current?.click()}
                disabled={televersementSignatureCachet}
                style={boutonSecondaireStyle}
              >
                {televersementSignatureCachet ? t("saCreating") : t("venteUploadSignatureCachetButton")}
              </button>
              {signatureCachet && (
                <button type="button" onClick={handleSupprimerSignatureCachet} disabled={televersementSignatureCachet} style={boutonSecondaireStyle}>
                  {t("venteRemoveSignatureCachetButton")}
                </button>
              )}
            </div>
            <input ref={inputSignatureCachetRef} type="file" accept="image/png,image/jpeg" onChange={handleChoisirSignatureCachet} style={{ display: "none" }} />
          </div>
          <p style={{ fontSize: 11, color: "var(--sub)", marginBottom: 16 }}>{t("venteSignatureCachetNote")}</p>

          <form onSubmit={handleEnregistrerTva}>
            <label style={labelStyle}>{t("venteTauxTvaLabel")}</label>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <input
                type="number"
                min="0"
                max="100"
                step="0.5"
                value={tauxTva}
                onChange={(e) => setTauxTva(e.target.value)}
                style={{ ...inputStyle, width: 120 }}
              />
              <span style={{ fontSize: 13 }}>%</span>
              <button type="submit" disabled={enregistrementTva} style={boutonPrincipalStyle}>
                {t("save")}
              </button>
              {confirmationTva && <span style={{ fontSize: 12.5, color: "var(--vert)" }}>{t("savedConfirmation")}</span>}
            </div>
            <p style={{ fontSize: 11, color: "var(--sub)", marginTop: 6 }}>{t("venteTauxTvaNote")}</p>
          </form>
        </div>
      )}

      {!chargement && (
        <div className="card" style={{ maxWidth: 560, marginTop: 16 }}>
          <h3 style={{ fontSize: 13.5, color: "var(--petrol)", marginBottom: 4 }}>{t("numerotationParametresSection")}</h3>
          <p style={{ fontSize: 11.5, color: "var(--sub)", marginBottom: 14 }}>{t("numerotationParametresDescription")}</p>

          <form onSubmit={handleEnregistrerNumerotation}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <label style={labelStyle}>{t("numerotationDevisLabel")}</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={numerotation.dernier_numero_devis}
                  onChange={(e) => setNumerotation((f) => ({ ...f, dernier_numero_devis: e.target.value }))}
                  style={inputStyle}
                />
              </div>
              <div>
                <label style={labelStyle}>{t("numerotationVenteLabel")}</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={numerotation.dernier_numero_vente}
                  onChange={(e) => setNumerotation((f) => ({ ...f, dernier_numero_vente: e.target.value }))}
                  style={inputStyle}
                />
              </div>
            </div>
            <p style={{ fontSize: 11, color: "var(--sub)", marginTop: 10 }}>{t("numerotationNote")}</p>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 12 }}>
              <button type="submit" disabled={enregistrementNumerotation} style={boutonPrincipalStyle}>
                {t("save")}
              </button>
              {confirmationNumerotation && (
                <span style={{ fontSize: 12.5, color: "var(--vert)" }}>{t("savedConfirmation")}</span>
              )}
            </div>
          </form>
        </div>
      )}

      {!chargement && (
        <div className="card" style={{ maxWidth: 560, marginTop: 16 }}>
          <h3 style={{ fontSize: 13.5, color: "var(--petrol)", marginBottom: 4 }}>{t("profilActiviteSection")}</h3>
          <p style={{ fontSize: 11.5, color: "var(--sub)", marginBottom: 12 }}>{t("profilActiviteDescription")}</p>
          <select
            value={profilActivite}
            onChange={(e) => handleChangerProfil(e.target.value)}
            style={inputStyle}
          >
            <option value="LES_DEUX">{t("profilActiviteLES_DEUX")}</option>
            <option value="NEGOCE">{t("profilActiviteNEGOCE")}</option>
            <option value="MARCHES">{t("profilActiviteMARCHES")}</option>
          </select>
        </div>
      )}

      {!chargement && (
        <div className="card" style={{ maxWidth: 560, marginTop: 16 }}>
          <h3 style={{ fontSize: 13.5, color: "var(--petrol)", marginBottom: 4 }}>{t("calcPrixParametresSection")}</h3>
          <p style={{ fontSize: 11.5, color: "var(--sub)", marginBottom: 14 }}>{t("calcPrixParametresDescription")}</p>

          <form onSubmit={handleEnregistrerCalculPrix}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {PARAM_DEFS_CALCUL_PRIX.map(({ cle, labelKey, type }) => type === "case" ? (
                <div key={cle} style={{ gridColumn: "1 / -1", background: "var(--fond, #f4f7f6)", borderRadius: 8, padding: "10px 12px" }}>
                  <label style={{ display: "flex", alignItems: "flex-start", gap: 8, fontSize: 12.5, cursor: "pointer" }}>
                    <input
                      type="checkbox"
                      checked={Number(formCalculPrix[cle]) === 1}
                      onChange={(e) => setFormCalculPrix((f) => ({ ...f, [cle]: e.target.checked ? 1 : 0 }))}
                      style={{ marginTop: 2 }}
                    />
                    <span>
                      <strong>{t(labelKey)}</strong>
                      <span style={{ display: "block", fontSize: 11, color: "var(--sub)", marginTop: 2 }}>{t("calcPrixRefacturerFraisPaiementAide")}</span>
                    </span>
                  </label>
                </div>
              ) : (
                <div key={cle}>
                  <label style={labelStyle}>{t(labelKey)}</label>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <input
                      type="number"
                      step="any"
                      value={formCalculPrix[cle] ?? ""}
                      onChange={(e) => setFormCalculPrix((f) => ({ ...f, [cle]: e.target.value }))}
                      style={inputStyle}
                    />
                    {type === "pourcentage" && <span style={{ fontSize: 13, flexShrink: 0 }}>%</span>}
                    {type === "montant" && <span style={{ fontSize: 11, color: "var(--sub)", flexShrink: 0 }}>XOF</span>}
                  </div>
                </div>
              ))}
            </div>
            <p style={{ fontSize: 11, color: "var(--sub)", marginTop: 10 }}>{t("calcPrixParametresNote")}</p>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 12 }}>
              <button type="submit" disabled={enregistrementCalculPrix} style={boutonPrincipalStyle}>
                {t("save")}
              </button>
              {confirmationCalculPrix && (
                <span style={{ fontSize: 12.5, color: "var(--vert)" }}>{t("savedConfirmation")}</span>
              )}
            </div>
          </form>
        </div>
      )}

      <div className="card" style={{ maxWidth: 560, marginTop: 16 }}>
        <h3 style={{ fontSize: 13.5, color: "var(--petrol)", marginBottom: 4 }}>{t("securitySection")}</h3>
        <p style={{ fontSize: 11.5, color: "var(--sub)", marginBottom: 14 }}>{t("securityDescription")}</p>
        <Link
          href="/changer-mot-de-passe"
          style={{ ...boutonSecondaireStyle, display: "inline-block", textDecoration: "none" }}
        >
          {t("securityChangePasswordLink")}
        </Link>
      </div>
    </AppShell>
  );
}

const labelStyle = { fontSize: 11.5, fontWeight: 600, display: "block", marginBottom: 5 };
const inputStyle = {
  width: "100%",
  padding: "8px 10px",
  border: "1px solid var(--line)",
  borderRadius: 8,
  fontSize: 13,
  fontFamily: "inherit",
};
const boutonPrincipalStyle = {
  background: "var(--petrol)",
  color: "#fff",
  border: "none",
  borderRadius: 8,
  padding: "8px 16px",
  fontSize: 12.5,
  fontWeight: 600,
};
const boutonSecondaireStyle = {
  background: "transparent",
  color: "var(--petrol)",
  border: "1px solid var(--line)",
  borderRadius: 8,
  padding: "7px 14px",
  fontSize: 12,
  fontWeight: 600,
  whiteSpace: "nowrap",
};
