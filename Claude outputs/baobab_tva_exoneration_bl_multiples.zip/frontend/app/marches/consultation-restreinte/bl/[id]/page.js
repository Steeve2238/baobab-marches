"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { api, estAdmin, getUtilisateurCourant } from "../../../../../lib/api";
import { useLangue } from "../../../../../lib/i18n/LanguageContext";
import AppShell from "../../../../../lib/components/AppShell";

// Formate une date "YYYY-MM-DD" en "JJ/MM/AAAA" sans jamais passer par un
// objet Date JS (qui reintroduirait une conversion de fuseau horaire cote
// navigateur) - voir le correctif equivalent cote serveur dans db.js.
function formaterDateAffichage(valeur) {
  if (!valeur) return "";
  const [annee, mois, jour] = String(valeur).slice(0, 10).split("-");
  return `${jour}/${mois}/${annee}`;
}

const STATUT_STYLE = {
  BROUILLON: { color: "var(--ocre)", background: "rgba(224,149,76,0.12)" },
  LIVRE: { color: "#2E7D5B", background: "rgba(46,125,91,0.12)" },
};

function possedeRole(codes) {
  if (estAdmin()) return true;
  const user = getUtilisateurCourant();
  return Array.isArray(user?.roles) && user.roles.some((r) => codes.includes(r));
}

function numeroAffiche(numero, mois) {
  // Numero manuel (ADMIN, chantier du 01/10/2026) : peut ne pas suivre le
  // format "AAAA-NNN" genere automatiquement - dans ce cas on l'affiche tel
  // quel, sans tenter d'y inserer le mois.
  if (!/^\d{4}-\d+$/.test(numero)) return numero;
  const [annee, sequence] = numero.split("-");
  return `${annee}-${String(mois).padStart(2, "0")}-${sequence}`;
}

export default function BlDetailPage() {
  const router = useRouter();
  const params = useParams();
  const { t } = useLangue();
  const [bl, setBl] = useState(null);
  const [entete, setEntete] = useState(null);
  const [erreur, setErreur] = useState("");
  const [avertStock, setAvertStock] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [action, setAction] = useState(false);
  const [lignesEdition, setLignesEdition] = useState([]);

  function charger() {
    Promise.all([api.getBl(params.id), api.getEntete(), api.getParametresVentes()])
      .then(([blData, enteteData, parametresData]) => {
        setBl(blData);
        setLignesEdition(blData.lignes.map((l) => ({ ...l })));
        setEntete({ ...enteteData, ...parametresData });
      })
      .catch((err) => {
        if (err.status === 401) {
          router.push("/login");
          return;
        }
        setErreur(err.message);
      })
      .finally(() => setChargement(false));
  }

  useEffect(charger, [params.id]);

  // Personnalise dynamiquement document.title (numero du BL + entreprise du
  // tenant) car document.title est injecte par le navigateur dans l'en-tete/
  // pied de page natif de l'impression - voir metadata globale dans
  // app/layout.js (titre "Baobab Marches" par defaut, ne pas modifier).
  useEffect(() => {
    if (!bl || !entete) return;
    const titrePrecedent = document.title;
    document.title = `${entete.raison_sociale || ""} - BL ${bl.numero}`.trim();
    return () => {
      document.title = titrePrecedent;
    };
  }, [bl, entete]);

  function majQuantite(index, valeur) {
    setLignesEdition((prev) => prev.map((l, i) => (i === index ? { ...l, quantite_livree: valeur } : l)));
  }

  async function handleEnregistrerLignes() {
    setAction(true);
    setErreur("");
    try {
      const maj = await api.patchBl(bl.id, {
        lignes: lignesEdition.map((l) => ({ id: l.id, designation: l.designation, unite: l.unite, quantite_livree: Number(l.quantite_livree) })),
      });
      setBl(maj);
      setLignesEdition(maj.lignes.map((l) => ({ ...l })));
    } catch (err) {
      setErreur(err.message);
    } finally {
      setAction(false);
    }
  }

  async function handleMarquerLivre() {
    setAction(true);
    setErreur("");
    try {
      const maj = await api.marquerBlLivre(bl.id);
      setBl((prev) => ({ ...prev, ...maj }));
      setAvertStock(maj.avertissements_stock || []);
      charger();
    } catch (err) {
      setErreur(err.message);
    } finally {
      setAction(false);
    }
  }

  if (chargement) {
    return (
      <AppShell title={t("venteBlDetailTitle")} backHref="/marches/consultation-restreinte/bl">
        <p style={{ fontSize: 12.5, color: "var(--sub)" }}>{t("loading")}</p>
      </AppShell>
    );
  }
  if (!bl) {
    return (
      <AppShell title={t("venteBlDetailTitle")} backHref="/marches/consultation-restreinte/bl">
        {erreur && <p style={{ color: "var(--brique)", fontSize: 12.5 }}>{erreur}</p>}
      </AppShell>
    );
  }

  const style = STATUT_STYLE[bl.statut] || {};
  const peutFacturer = possedeRole(["COMPTABLE", "FINANCIER"]);
  const modifiable = bl.statut === "BROUILLON" && peutFacturer;
  const numeroComplet = numeroAffiche(bl.numero, bl.mois_emission) + (bl.rang > 1 ? `/${bl.rang}` : "");
  const lignesAffichees = modifiable ? lignesEdition : bl.lignes;
  const suiviReste = (bl.lignes || []).some((l) => l.facture_ligne_id);

  return (
    <AppShell title={`BL-${numeroComplet}`} backHref="/marches/consultation-restreinte/bl">
      {erreur && <p className="no-print" style={{ color: "var(--brique)", fontSize: 12.5, marginBottom: 14 }}>{erreur}</p>}
      {avertStock.length > 0 && (
        <div className="no-print" style={{ color: "var(--brique)", fontSize: 12.5, marginBottom: 14 }}>
          <strong>{t("venteStockNegatifTitre")}</strong>
          {avertStock.map((a) => (
            <div key={a.produit_id}>
              {a.reference ? `${a.reference} · ` : ""}{a.designation} : {Number(a.stock).toLocaleString()}
            </div>
          ))}
        </div>
      )}

      <div className="no-print" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
        <span style={{ fontSize: 11, fontWeight: 700, padding: "4px 10px", borderRadius: 20, ...style }}>
          {t(`venteBlStatut_${bl.statut}`)}
        </span>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {modifiable && (
            <button onClick={handleEnregistrerLignes} disabled={action} style={boutonSecondaireStyle}>
              {t("save")}
            </button>
          )}
          {modifiable && (
            <button onClick={handleMarquerLivre} disabled={action} style={boutonPrincipalStyle}>
              {t("venteMarkDeliveredButton")}
            </button>
          )}
          <button onClick={() => window.print()} style={boutonSecondaireStyle}>
            {t("print")}
          </button>
        </div>
      </div>

      {modifiable && (
        <p className="no-print" style={{ fontSize: 11.5, color: "var(--sub)", marginBottom: 12 }}>{t("venteBlPartialNote")}</p>
      )}

      <div className="card print-letter" style={{ padding: "28px 32px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 24, borderBottom: "2px solid var(--petrol)", paddingBottom: 16, marginBottom: 20 }}>
          <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
            {entete?.logo_base64 && (
              <img
                src={`data:${entete.logo_type_mime};base64,${entete.logo_base64}`}
                alt="logo"
                style={{ maxWidth: 90, maxHeight: 70, objectFit: "contain" }}
              />
            )}
            <div>
              <div style={{ fontFamily: "Space Grotesk", fontWeight: 700, fontSize: 14, color: "var(--petrol)" }}>
                {entete?.raison_sociale || "—"}
              </div>
              <div style={{ fontSize: 11, color: "var(--sub)", marginTop: 2 }}>{entete?.adresse}</div>
              <div style={{ fontSize: 11, color: "var(--sub)" }}>{entete?.telephone}</div>
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontWeight: 700, fontSize: 13.5 }}>{t("venteBlNumberLabel")} BL-{numeroComplet}</div>
            <div style={{ fontSize: 11.5, color: "var(--sub)" }}>{formaterDateAffichage(bl.date_bl)}</div>
          </div>
        </div>

        <div style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 10.5, fontWeight: 700, color: "var(--sub)", textTransform: "uppercase" }}>{t("venteDeliverToLabel")}</div>
          <div style={{ fontWeight: 600, fontSize: 13.5 }}>{bl.client_nom}</div>
          {bl.client_adresse && <div style={{ fontSize: 12, color: "var(--sub)" }}>{bl.client_adresse}</div>}
        </div>

        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ fontSize: 11, textAlign: "left", borderBottom: "1px solid var(--line)" }}>
              {(bl.lignes || []).some((l) => l.reference) && <th style={{ padding: "6px 4px" }}>{t("venteReferenceLabel")}</th>}
              <th style={{ padding: "6px 4px" }}>{t("venteDesignationLabel")}</th>
              <th style={{ padding: "6px 4px" }}>{t("venteUniteLabel")}</th>
              {suiviReste && <th style={{ padding: "6px 4px", textAlign: "right" }}>{t("venteQuantiteFactureeLabel")}</th>}
              {suiviReste && <th style={{ padding: "6px 4px", textAlign: "right" }}>{t("venteDejaLivreeLabel")}</th>}
              <th style={{ padding: "6px 4px", textAlign: "right" }}>{t("venteQuantiteLivreeLabel")}</th>
              {suiviReste && <th style={{ padding: "6px 4px", textAlign: "right" }}>{t("venteResteALivrerLabel")}</th>}
            </tr>
          </thead>
          <tbody>
            {lignesAffichees.map((l, index) => (
              <tr key={l.id || index} style={{ borderBottom: "1px solid var(--line-soft)" }}>
                {(bl.lignes || []).some((l) => l.reference) && <td className="mono" style={{ padding: "6px 4px", fontSize: 12 }}>{l.reference || ""}</td>}
                <td style={{ padding: "6px 4px", fontSize: 12.5 }}>{l.designation}</td>
                <td style={{ padding: "6px 4px", fontSize: 12.5 }}>{l.unite}</td>
                {suiviReste && (
                  <td className="mono" style={{ padding: "6px 4px", fontSize: 12.5, textAlign: "right" }}>
                    {l.quantite_facturee != null ? Number(l.quantite_facturee).toLocaleString() : "—"}
                  </td>
                )}
                {suiviReste && (
                  <td className="mono" style={{ padding: "6px 4px", fontSize: 12.5, textAlign: "right" }}>
                    {l.deja_livree != null ? Number(l.deja_livree).toLocaleString() : "—"}
                  </td>
                )}
                <td style={{ padding: "6px 4px", fontSize: 12.5, textAlign: "right" }}>
                  {modifiable ? (
                    <input
                      type="number"
                      min="0"
                      max={l.quantite_facturee != null ? Math.max(0, Number(l.quantite_facturee) - Number(l.deja_livree || 0)) : undefined}
                      step="0.01"
                      value={l.quantite_livree}
                      onChange={(e) => majQuantite(index, e.target.value)}
                      style={{ ...inputStyleCompact, width: 90, textAlign: "right" }}
                    />
                  ) : (
                    <span className="mono">{Number(l.quantite_livree).toLocaleString()}</span>
                  )}
                </td>
                {suiviReste && (
                  <td className="mono" style={{ padding: "6px 4px", fontSize: 12.5, textAlign: "right", fontWeight: 700 }}>
                    {l.quantite_facturee != null
                      ? Math.max(0, Math.round((Number(l.quantite_facturee) - Number(l.deja_livree || 0) - (Number(l.quantite_livree) || 0)) * 100) / 100).toLocaleString()
                      : "—"}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>

        <div style={{ marginTop: 110, display: "flex", justifyContent: "space-between" }}>
          <div style={{ fontSize: 11.5, color: "var(--sub)" }}>{t("venteReceivedBySignature")}</div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontWeight: 700, fontSize: 12.5 }}>{entete?.signataire_nom}</div>
            <div style={{ fontSize: 11.5, color: "var(--sub)" }}>{entete?.signataire_titre}</div>
            {entete?.signature_cachet_base64 && (
              <img
                src={`data:${entete.signature_cachet_type_mime};base64,${entete.signature_cachet_base64}`}
                alt="signature et cachet"
                style={{ maxWidth: 150, maxHeight: 100, objectFit: "contain", marginTop: 8 }}
              />
            )}
          </div>
        </div>

        {piedDePage(entete).length > 0 && (
          <div
            style={{
              marginTop: 40,
              paddingTop: 12,
              borderTop: "1px solid var(--line)",
              textAlign: "center",
              fontSize: 10.5,
              color: "var(--sub)",
            }}
          >
            {piedDePage(entete).join(" · ")}
          </div>
        )}
      </div>
    </AppShell>
  );
}

// Pied de page (mentions legales) des documents imprimables - RCCM, NINEA,
// site web, coordonnees bancaires (voir migration
// 018_facturation_entete_pied_de_page.sql) : seuls les champs renseignes par
// l'entreprise s'affichent, rien n'est obligatoire.
function piedDePage(entete) {
  return [
    entete?.rccm ? `RCCM ${entete.rccm}` : null,
    entete?.ninea ? `NINEA ${entete.ninea}` : null,
    entete?.site_web || null,
    entete?.coordonnees_bancaires || null,
  ].filter(Boolean);
}

const boutonPrincipalStyle = {
  background: "var(--petrol)",
  color: "#fff",
  border: "none",
  borderRadius: 8,
  padding: "8px 16px",
  fontSize: 12,
  fontWeight: 600,
  whiteSpace: "nowrap",
};
const boutonSecondaireStyle = {
  background: "transparent",
  color: "var(--petrol)",
  border: "1px solid var(--line)",
  borderRadius: 8,
  padding: "7px 14px",
  fontSize: 12,
  fontWeight: 600,
  whiteSpace: "nowrap",
};
const inputStyleCompact = {
  padding: "5px 8px",
  border: "1px solid var(--line)",
  borderRadius: 6,
  fontSize: 12.5,
  fontFamily: "inherit",
};
