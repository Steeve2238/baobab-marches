/* © YMS Groupe - Baobab Marchés. Tous droits réservés. Logiciel propriétaire : voir COPYRIGHT.md. */
require("dotenv").config();
const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/auth");
const dossiersRoutes = require("./routes/dossiers");
const chronogrammeRoutes = require("./routes/chronogramme");
const signauxRoutes = require("./routes/signaux");
const tableauBordRoutes = require("./routes/tableauBord");
const regleRoutes = require("./routes/regles");
const financementRoutes = require("./routes/financement");
const margeRoutes = require("./routes/marge");
const logistiqueRoutes = require("./routes/logistique");
const courriersRoutes = require("./routes/courriers");
const parametresRoutes = require("./routes/parametres");
const fournisseursRoutes = require("./routes/fournisseurs");
const echeanciersRoutes = require("./routes/echeanciers");
const extractionRoutes = require("./routes/extraction");
const rolesRoutes = require("./routes/roles");
const utilisateursRoutes = require("./routes/utilisateurs");
const maitresOuvrageRoutes = require("./routes/maitresOuvrage");
const concurrenceRoutes = require("./routes/concurrence");
const parcAutoRoutes = require("./routes/parcAuto");
const rhEspaceRoutes = require("./routes/rhEspace");
const rhRoutes = require("./routes/rh");
const rhContratsRoutes = require("./routes/rhContrats");
const rhCourriersRoutes = require("./routes/rhCourriers");
const rhOrdresVirementRoutes = require("./routes/rhOrdresVirement");
const superAdminRoutes = require("./routes/superAdmin");
const ventesRoutes = require("./routes/ventes");
const modesReglementRoutes = require("./routes/modesReglement");
const caisseRoutes = require("./routes/caisse");
const calculPrixRoutes = require("./routes/calculPrix");
const produitsRoutes = require("./routes/produits");
const receptionsRoutes = require("./routes/receptions");
const prixFournisseursRoutes = require("./routes/prixFournisseurs");
const transitairesRoutes = require("./routes/transitaires");
const commandesRoutes = require("./routes/commandes");
const incotermsRoutes = require("./routes/incoterms");
const livraisonsDossierRoutes = require("./routes/livraisonsDossier");
const comptabiliteRoutes = require("./routes/comptabilite");
const fiscaliteRoutes = require("./routes/fiscalite");
const paieRoutes = require("./routes/paie");
const { t } = require("./utils/i18n");

const app = express();

app.use(cors());
// RH : signature (image) et exemplaires scannes du contrat voyagent en base64 dans le JSON : limites dediees.
app.use("/api/rh/espace/signature", express.json({ limit: "1mb" }));
app.use(/^\/api\/rh\/contrats\/[^/]+\/(scan|viser)$/, express.json({ limit: "12mb" }));
app.use(express.json());

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    service: "baobab-marches-backend",
  });
});

app.use("/api/auth", authRoutes);
app.use("/api/dossiers", dossiersRoutes);
app.use("/api/chronogramme", chronogrammeRoutes);
app.use("/api/signaux", signauxRoutes);
app.use("/api/tableau-bord", tableauBordRoutes);
app.use("/api/regles", regleRoutes);
app.use("/api/financement", financementRoutes);
app.use("/api/marge", margeRoutes);
app.use("/api/logistique", logistiqueRoutes);
app.use("/api/courriers", courriersRoutes);
app.use("/api/parametres", parametresRoutes);
app.use("/api/fournisseurs", fournisseursRoutes);
app.use("/api/echeanciers", echeanciersRoutes);
app.use("/api/extraction", extractionRoutes);
app.use("/api/roles", rolesRoutes);
app.use("/api/utilisateurs", utilisateursRoutes);
app.use("/api/maitres-ouvrage", maitresOuvrageRoutes);
app.use("/api/concurrence", concurrenceRoutes);
app.use("/api/parc-auto", parcAutoRoutes);
app.use("/api/rh/espace", rhEspaceRoutes);
app.use("/api/rh", rhRoutes);
app.use("/api/rh", rhContratsRoutes);
app.use("/api/rh", rhCourriersRoutes);
app.use("/api/rh", rhOrdresVirementRoutes);
app.use("/api/super-admin", superAdminRoutes);
app.use("/api/ventes", ventesRoutes);
app.use("/api/modes-reglement", modesReglementRoutes);
app.use("/api/caisse", caisseRoutes);
app.use("/api/calcul-prix", calculPrixRoutes);
app.use("/api/produits", produitsRoutes);
app.use("/api/receptions", receptionsRoutes);
app.use("/api/prix-fournisseurs", prixFournisseursRoutes);
app.use("/api/transitaires", transitairesRoutes);
app.use("/api/commandes", commandesRoutes);
app.use("/api/incoterms", incotermsRoutes);
app.use("/api/livraisons-dossier", livraisonsDossierRoutes);
app.use("/api/comptabilite", comptabiliteRoutes);
app.use("/api/fiscalite", fiscaliteRoutes);
app.use("/api/paie", paieRoutes);

// Gestionnaire d'erreur generique (dernier recours)
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: t(req, "SERVER_ERROR") });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Baobab Marches API demarree sur le port ${PORT}`);
});
