/**
 * Module Fiscalite - calendrier des obligations fiscales, alertes et estimateur de penalites.
 *
 * Echeances generees pour une annee civile (dates du CGI 2025) :
 *   - TVA mensuelle : depot et paiement au plus tard le 15 du mois suivant (declaration preparee dans le module) ;
 *   - retenues a la source du mois (BRS, loyers, non-residents...) : versement avant le 15 du mois suivant
 *     (suivi manuel : le module ne calcule pas encore ces retenues) ;
 *   - impot sur les societes : 1er acompte avant le 15 fevrier, 2e acompte au plus tard le 30 avril, declaration des
 *     resultats au plus tard le 30 avril, solde au plus tard le 15 juin (art. 133, 214) ;
 *   - contribution economique locale : declaration de la CVA au plus tard le 30 avril, paiement au plus tard le
 *     31 juillet (art. 341, 342).
 * L'IS est calendaire (exercice clos le 31 decembre) : pour une autre date de cloture, les dates sont a adapter.
 */
const db = require("../db");
const { v4: uuidv4 } = require("uuid");
const { FiscaliteError, dateLimite } = require("./fiscaliteTva");

const pad = (n) => String(n).padStart(2, "0");
const num = (v) => Number(v || 0);

const STATUTS = ["A_FAIRE", "PREPAREE", "DEPOSEE", "PAYEE", "NON_CONCERNE"];

function genererEcheances(annee) {
  const e = [];
  // TVA et retenues : decembre N-1 (du 15 janvier N) a novembre N (du 15 decembre N)
  for (let k = 0; k < 12; k++) {
    const mois = k === 0 ? 12 : k;
    const an = k === 0 ? annee - 1 : annee;
    const cleMois = `${an}-${pad(mois)}`;
    const limite = dateLimite(an, mois);
    e.push({ cle: `TVA:${cleMois}`, type: "TVA", libelle_cle: "TVA", periode: cleMois, date_limite: limite, annee_periode: an, mois_periode: mois, automatique: true });
    e.push({ cle: `RETENUES:${cleMois}`, type: "RETENUES", libelle_cle: "RETENUES", periode: cleMois, date_limite: limite, annee_periode: an, mois_periode: mois, automatique: false });
  }
  e.push({ cle: `IS_ACOMPTE_1:${annee}`, type: "IS_ACOMPTE_1", periode: String(annee), date_limite: `${annee}-02-15`, automatique: false });
  e.push({ cle: `IS_ACOMPTE_2:${annee}`, type: "IS_ACOMPTE_2", periode: String(annee), date_limite: `${annee}-04-30`, automatique: false });
  e.push({ cle: `IS_DECLARATION:${annee}`, type: "IS_DECLARATION", periode: String(annee - 1), date_limite: `${annee}-04-30`, automatique: false });
  e.push({ cle: `IS_SOLDE:${annee}`, type: "IS_SOLDE", periode: String(annee - 1), date_limite: `${annee}-06-15`, automatique: false });
  e.push({ cle: `CEL_DECLARATION:${annee}`, type: "CEL_DECLARATION", periode: String(annee), date_limite: `${annee}-04-30`, automatique: false });
  e.push({ cle: `CEL_PAIEMENT:${annee}`, type: "CEL_PAIEMENT", periode: String(annee), date_limite: `${annee}-07-31`, automatique: false });
  return e.sort((a, b) => a.date_limite.localeCompare(b.date_limite) || a.type.localeCompare(b.type));
}

function joursEntre(a, b) {
  const da = Date.UTC(...a.split("-").map((x, i) => (i === 1 ? Number(x) - 1 : Number(x))));
  const db_ = Date.UTC(...b.split("-").map((x, i) => (i === 1 ? Number(x) - 1 : Number(x))));
  return Math.round((db_ - da) / 86400000);
}

function aujourdhui() {
  return new Date().toISOString().slice(0, 10);
}

/**
 * Estimation indicative des sanctions pour un impot paye / depose avec retard (art. 665, 667, 671 du CGI) :
 *   - interet de retard : 5 % du solde impaye + 0,5 % par mois ou fraction de mois de retard supplementaire ;
 *   - penalite de 25 % des droits eludes en cas de defaut de declaration ou de paiement (art. 671 I) - 50 % si
 *     l'impot collecte n'est pas reverse (art. 671 III 1°), comme la TVA facturee ;
 *   - amende de 200 000 F pour manquement a une obligation declarative sans amende specifique (art. 667).
 * Ce n'est ni une liquidation ni un conseil : l'administration fixe seule le montant definitif.
 */
function estimerPenalites({ montant, jours_retard, type = "TVA", declaration_deposee = false }) {
  const m = Math.max(0, num(montant));
  const jours = Math.max(0, Math.round(num(jours_retard)));
  if (jours === 0 || m === 0) {
    return { jours_retard: jours, mois_retard: 0, interet_retard: 0, penalite: 0, taux_penalite: 0, amende: 0, total: 0, hypotheses: [] };
  }
  const mois = Math.ceil(jours / 30);
  const tauxInteret = 5 + 0.5 * Math.max(0, mois - 1);
  const interet = Math.round((m * tauxInteret) / 100);
  const collecte = type === "TVA";
  const tauxPenalite = collecte ? 50 : 25;
  const penalite = Math.round((m * tauxPenalite) / 100);
  const amende = declaration_deposee ? 0 : 200000;
  return {
    jours_retard: jours,
    mois_retard: mois,
    taux_interet: tauxInteret,
    interet_retard: interet,
    taux_penalite: tauxPenalite,
    penalite,
    amende,
    total: interet + penalite + amende,
    hypotheses: [
      "INTERET_5_PLUS_05_PAR_MOIS",
      collecte ? "PENALITE_50_TVA_COLLECTEE_NON_REVERSEE" : "PENALITE_25_DEFAUT_PAIEMENT",
      declaration_deposee ? "DECLARATION_DEPOSEE_PAS_AMENDE" : "AMENDE_200000_DEFAUT_DECLARATION",
    ],
  };
}

async function lister(tenantId, annee) {
  const echeances = genererEcheances(annee);
  const cles = echeances.map((x) => x.cle);
  const suivis = await db.query(`SELECT * FROM fiscalite_suivi WHERE tenant_id = $1 AND cle = ANY($2)`, [tenantId, cles]);
  const parCle = new Map(suivis.rows.map((x) => [x.cle, x]));
  const tva = await db.query(
    `SELECT annee, mois, statut, solde_a_payer, credit_a_reporter, date_depot, date_paiement FROM fiscalite_declaration_tva
     WHERE tenant_id = $1 AND (annee = $2 OR (annee = $3 AND mois = 12))`,
    [tenantId, annee, annee - 1]
  );
  const parTva = new Map(tva.rows.map((x) => [`TVA:${x.annee}-${pad(x.mois)}`, x]));
  const dossiersIs = await db.query(
    `SELECT annee, statut, impot_du, solde_a_payer, date_depot, date_paiement, calcul_json FROM fiscalite_is_dossier WHERE tenant_id = $1 AND annee BETWEEN $2 AND $3`,
    [tenantId, annee - 2, annee]
  );
  const parIs = new Map(dossiersIs.rows.map((x) => [x.annee, x]));
  const paiementsIs = await db.query(
    `SELECT annee_exercice, nature, SUM(montant) AS total, MAX(date_paiement) AS dernier FROM fiscalite_is_paiement WHERE tenant_id = $1 AND annee_exercice BETWEEN $2 AND $3 GROUP BY annee_exercice, nature`,
    [tenantId, annee - 2, annee]
  );
  const parPaiement = new Map(paiementsIs.rows.map((x) => [`${x.annee_exercice}:${x.nature}`, x]));
  const auj = aujourdhui();
  // Les echeances anterieures a l'activation du module (moins un mois de tolerance) ne sont pas suivies par la
  // plateforme : elles ne declenchent ni retard ni alerte (la TVA de ces mois a ete deposee hors plateforme).
  const t = await db.query(`SELECT COALESCE(module_fiscalite_date_activation, date_creation) AS debut FROM tenant WHERE id = $1`, [tenantId]);
  const debutSuivi = new Date(new Date(t.rows[0]?.debut || Date.now()).getTime() - 31 * 86400000).toISOString().slice(0, 10);

  return echeances.map((e) => {
    const s = parCle.get(e.cle);
    const d = parTva.get(e.cle);
    let statut = s ? s.statut : "A_FAIRE";
    let montant = s && s.montant !== null ? num(s.montant) : null;
    let dateDepot = s && s.date_depot ? String(s.date_depot).slice(0, 10) : null;
    let datePaiement = s && s.date_paiement ? String(s.date_paiement).slice(0, 10) : null;
    if (e.type === "TVA" && d) {
      statut = d.statut;
      montant = num(d.solde_a_payer);
      dateDepot = d.date_depot ? String(d.date_depot).slice(0, 10) : null;
      datePaiement = d.date_paiement ? String(d.date_paiement).slice(0, 10) : null;
    }
    // IS : l'exercice de l'echeance est annee - 1 ; les donnees viennent du dossier IS (module) quand il existe.
    if (e.type.startsWith("IS_")) {
      const ex = annee - 1;
      const dos = parIs.get(ex);
      if (e.type === "IS_DECLARATION" && dos && dos.statut !== "BROUILLON") {
        statut = dos.statut === "PREPAREE" ? "PREPAREE" : "DEPOSEE";
        dateDepot = dos.date_depot ? String(dos.date_depot).slice(0, 10) : null;
        montant = dos.impot_du === null ? montant : num(dos.impot_du);
      } else if (e.type === "IS_SOLDE" && dos && dos.statut !== "BROUILLON") {
        montant = dos.solde_a_payer === null ? montant : num(dos.solde_a_payer);
        const verse = parPaiement.get(`${ex}:SOLDE`);
        if (dos.statut === "PAYEE" || (verse && num(verse.total) >= num(dos.solde_a_payer) && num(dos.solde_a_payer) > 0) || (dos.statut !== "PREPAREE" && num(dos.solde_a_payer) === 0)) {
          statut = "PAYEE";
          datePaiement = dos.date_paiement ? String(dos.date_paiement).slice(0, 10) : verse ? String(verse.dernier).slice(0, 10) : null;
        } else statut = "A_FAIRE";
        if (dos.statut === "PREPAREE") statut = "PREPAREE";
      } else if (e.type === "IS_ACOMPTE_1" || e.type === "IS_ACOMPTE_2") {
        const plan = dos && dos.calcul_json && dos.calcul_json.acomptes && dos.calcul_json.acomptes.plan;
        const nature = e.type === "IS_ACOMPTE_1" ? "ACOMPTE_1" : "ACOMPTE_2";
        const verse = parPaiement.get(`${ex}:${nature}`);
        if (plan && plan[e.type === "IS_ACOMPTE_1" ? "acompte_1" : "acompte_2"] !== null && montant === null) montant = plan[e.type === "IS_ACOMPTE_1" ? "acompte_1" : "acompte_2"];
        if (verse) {
          statut = "PAYEE";
          montant = num(verse.total);
          datePaiement = String(verse.dernier).slice(0, 10);
        }
      }
    }
    // Deposee mais pas encore payee avec un montant a regler : l'echeance de paiement reste ouverte.
    const clos = statut === "PAYEE" || statut === "NON_CONCERNE" || (statut === "DEPOSEE" && (!(montant > 0) || e.type === "IS_DECLARATION"));
    const joursRestants = joursEntre(auj, e.date_limite);
    let alerte = "OK";
    if (!clos && e.date_limite < debutSuivi && statut === "A_FAIRE") {
      alerte = "HISTORIQUE";
    } else if (!clos) {
      if (joursRestants < 0) alerte = "EN_RETARD";
      else if (joursRestants <= 10) alerte = "IMMINENT";
      else alerte = "A_VENIR";
    }
    const penalites = alerte === "EN_RETARD" && montant ? estimerPenalites({ montant, jours_retard: -joursRestants, type: e.type === "TVA" ? "TVA" : "AUTRE", declaration_deposee: statut === "DEPOSEE" }) : null;
    return {
      ...e,
      statut,
      montant,
      date_depot: dateDepot,
      date_paiement: datePaiement,
      reference: s ? s.reference : null,
      note: s ? s.note : null,
      jours_restants: joursRestants,
      alerte,
      penalites_estimees: penalites,
    };
  });
}

async function majSuivi(tenantId, userId, cle, corps) {
  if (typeof cle !== "string" || !/^[A-Z_0-9]+:[0-9-]{4,7}$/.test(cle)) throw new FiscaliteError("FISCALITE_CODE_INVALIDE");
  const c = corps || {};
  if (!STATUTS.includes(c.statut)) throw new FiscaliteError("FISCALITE_CODE_INVALIDE");
  const estDate = (v) => v === null || v === undefined || v === "" || (typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v));
  if (!estDate(c.date_depot) || !estDate(c.date_paiement)) throw new FiscaliteError("FISCALITE_DATE_INVALIDE");
  let montant = null;
  if (c.montant !== undefined && c.montant !== null && c.montant !== "") {
    montant = Number(c.montant);
    if (!Number.isFinite(montant) || montant < 0) throw new FiscaliteError("FISCALITE_MONTANT_INVALIDE");
  }
  await db.query(
    `INSERT INTO fiscalite_suivi (id, tenant_id, cle, statut, date_depot, date_paiement, reference, montant, note, mis_a_jour_par, date_modification)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10, now())
     ON CONFLICT (tenant_id, cle) DO UPDATE SET statut = EXCLUDED.statut, date_depot = EXCLUDED.date_depot, date_paiement = EXCLUDED.date_paiement,
       reference = EXCLUDED.reference, montant = EXCLUDED.montant, note = EXCLUDED.note, mis_a_jour_par = EXCLUDED.mis_a_jour_par, date_modification = now()`,
    [uuidv4(), tenantId, cle, c.statut, c.date_depot || null, c.date_paiement || null, (c.reference || "").trim() || null, montant, (c.note || "").trim() || null, userId]
  );
}

/** Synthese pour le tableau de bord : retards et echeances des 30 prochains jours. */
async function synthese(tenantId, annee) {
  const toutes = await lister(tenantId, annee);
  const ouvertes = toutes.filter((x) => ["EN_RETARD", "IMMINENT", "A_VENIR"].includes(x.alerte));
  return {
    annee,
    en_retard: toutes.filter((x) => x.alerte === "EN_RETARD"),
    imminentes: toutes.filter((x) => x.alerte === "IMMINENT"),
    prochaines: ouvertes.filter((x) => x.jours_restants >= 0 && x.jours_restants <= 45).slice(0, 8),
    total: toutes.length,
    faites: toutes.filter((x) => x.alerte === "OK").length,
  };
}

module.exports = { genererEcheances, estimerPenalites, lister, majSuivi, synthese, STATUTS };
