"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "../../../lib/api";
import { useLangue } from "../../../lib/i18n/LanguageContext";
import AppShell from "../../../lib/components/AppShell";
import { DEVISES } from "../../../lib/constants/devises";
import { useProfilActivite } from "../../../lib/useProfilActivite";

function FormulaireAppelOffres() {
  const router = useRouter();
  const { t } = useLangue();
  const [maitresOuvrage, setMaitresOuvrage] = useState([]);
  const [erreur, setErreur] = useState("");
  const [enCours, setEnCours] = useState(false);
  const [form, setForm] = useState({
    intitule: "",
    reference_externe: "",
    maitre_ouvrage_id: "",
    secteur: "",
    montant_estime: "",
    devise: "XOF",
    date_limite_soumission: "",
  });

  // Ajout rapide d'un maitre d'ouvrage directement depuis ce formulaire
  // (demande de Steeve, rapport client 24/09/2026) : evite de quitter la
  // creation du dossier pour aller enregistrer le maitre d'ouvrage ailleurs.
  const [ajoutMaitreOuvrageOuvert, setAjoutMaitreOuvrageOuvert] = useState(false);
  const [nouveauMaitreOuvrage, setNouveauMaitreOuvrage] = useState({ nom: "", categorie: "" });
  const [maitreOuvrageEnCours, setMaitreOuvrageEnCours] = useState(false);

  useEffect(() => {
    api.getMaitresOuvrage().then(setMaitresOuvrage).catch((err) => setErreur(err.message));
  }, []);

  async function handleCreerMaitreOuvrage() {
    setMaitreOuvrageEnCours(true);
    try {
      const nouveau = await api.createMaitreOuvrage(nouveauMaitreOuvrage);
      setMaitresOuvrage((prev) => [...prev, nouveau].sort((a, b) => a.nom.localeCompare(b.nom)));
      setForm((f) => ({ ...f, maitre_ouvrage_id: nouveau.id }));
      setAjoutMaitreOuvrageOuvert(false);
      setNouveauMaitreOuvrage({ nom: "", categorie: "" });
    } catch (err) {
      setErreur(err.message);
    } finally {
      setMaitreOuvrageEnCours(false);
    }
  }

  async function handleCreer(e) {
    e.preventDefault();
    setEnCours(true);
    try {
      const nouveau = await api.createDossier({
        ...form,
        maitre_ouvrage_id: form.maitre_ouvrage_id || null,
        montant_estime: form.montant_estime ? Number(form.montant_estime) : null,
        date_limite_soumission: form.date_limite_soumission || null,
      });
      router.push(`/dossiers/${nouveau.id}`);
    } catch (err) {
      setErreur(err.message);
      setEnCours(false);
    }
  }

  return (
    <AppShell title={t("dossierNewPageTitle")}>
      <Link href="/dashboard" style={{ fontSize: 12, color: "var(--petrol)", display: "inline-block", marginBottom: 12 }}>
        {t("backToDashboard")}
      </Link>

      {erreur && <p style={{ color: "var(--brique)", fontSize: 12.5, marginBottom: 14 }}>{erreur}</p>}

      <form onSubmit={handleCreer} className="card" style={{ maxWidth: 560 }}>
        <label style={labelStyle}>{t("intituleLabel")}</label>
        <input
          required
          value={form.intitule}
          onChange={(e) => setForm((f) => ({ ...f, intitule: e.target.value }))}
          style={inputStyle}
        />

        <label style={{ ...labelStyle, marginTop: 10 }}>{t("referenceExterneLabel")}</label>
        <input
          value={form.reference_externe}
          onChange={(e) => setForm((f) => ({ ...f, reference_externe: e.target.value }))}
          style={inputStyle}
        />

        <label style={{ ...labelStyle, marginTop: 10 }}>{t("maitreOuvrageLabel")}</label>
        <select
          value={form.maitre_ouvrage_id}
          onChange={(e) => setForm((f) => ({ ...f, maitre_ouvrage_id: e.target.value }))}
          style={inputStyle}
        >
          <option value="">{t("selectMaitreOuvrage")}</option>
          {maitresOuvrage.map((m) => (
            <option key={m.id} value={m.id}>
              {m.nom}
            </option>
          ))}
        </select>
        <button
          type="button"
          onClick={() => setAjoutMaitreOuvrageOuvert((v) => !v)}
          style={{ ...boutonLienStyle, marginTop: 4 }}
        >
          {t("dossierQuickAddMaitreOuvrage")}
        </button>
        {ajoutMaitreOuvrageOuvert && (
          <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
            <input
              placeholder={t("dossierNewMaitreOuvrageNomLabel")}
              value={nouveauMaitreOuvrage.nom}
              onChange={(e) => setNouveauMaitreOuvrage((f) => ({ ...f, nom: e.target.value }))}
              style={{ ...inputStyle, fontSize: 11.5, padding: "5px 8px" }}
            />
            <input
              placeholder={t("dossierNewMaitreOuvrageCategorieLabel")}
              value={nouveauMaitreOuvrage.categorie}
              onChange={(e) => setNouveauMaitreOuvrage((f) => ({ ...f, categorie: e.target.value }))}
              style={{ ...inputStyle, fontSize: 11.5, padding: "5px 8px", maxWidth: 120 }}
            />
            <button
              type="button"
              onClick={handleCreerMaitreOuvrage}
              disabled={maitreOuvrageEnCours || !nouveauMaitreOuvrage.nom.trim()}
              style={boutonSecondaireStyle}
            >
              {t("save")}
            </button>
          </div>
        )}

        <label style={{ ...labelStyle, marginTop: 10 }}>{t("secteurLabel")}</label>
        <input
          value={form.secteur}
          onChange={(e) => setForm((f) => ({ ...f, secteur: e.target.value }))}
          style={inputStyle}
        />

        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 12, marginTop: 10 }}>
          <div>
            <label style={labelStyle}>{t("montantEstimeLabel")}</label>
            <input
              type="number"
              step="0.01"
              value={form.montant_estime}
              onChange={(e) => setForm((f) => ({ ...f, montant_estime: e.target.value }))}
              style={inputStyle}
            />
          </div>
          <div>
            <label style={labelStyle}>{t("deviseLabel")}</label>
            <select
              value={form.devise}
              onChange={(e) => setForm((f) => ({ ...f, devise: e.target.value }))}
              style={inputStyle}
            >
              {DEVISES.map((d) => (
                <option key={d.code} value={d.code}>
                  {d.code}
                </option>
              ))}
            </select>
          </div>
        </div>

        <label style={{ ...labelStyle, marginTop: 10 }}>{t("dateLimiteSoumissionLabel")}</label>
        <input
          type="datetime-local"
          value={form.date_limite_soumission}
          onChange={(e) => setForm((f) => ({ ...f, date_limite_soumission: e.target.value }))}
          style={inputStyle}
        />
        <p style={{ fontSize: 11, color: "var(--sub)", marginTop: 5 }}>{t("dateLimiteSoumissionHint")}</p>

        <button type="submit" disabled={enCours} style={{ ...boutonPrincipalStyle, marginTop: 14, width: "100%" }}>
          {t("createDossierButton")}
        </button>
      </form>
    </AppShell>
  );
}

const labelStyle = { fontSize: 11.5, fontWeight: 600, display: "block", marginBottom: 5 };
const inputStyle = {
  width: "100%",
  padding: "8px 10px",
  border: "1px solid var(--line)",
  borderRadius: 8,
  fontSize: 13,
  fontFamily: "inherit",
};
const boutonPrincipalStyle = {
  background: "var(--petrol)",
  color: "#fff",
  border: "none",
  borderRadius: 8,
  padding: "8px 16px",
  fontSize: 12.5,
  fontWeight: 600,
};
const boutonSecondaireStyle = {
  background: "transparent",
  color: "var(--petrol)",
  border: "1px solid var(--line)",
  borderRadius: 8,
  padding: "6px 12px",
  fontSize: 12,
  fontWeight: 600,
  whiteSpace: "nowrap",
};
const boutonLienStyle = {
  background: "none",
  border: "none",
  color: "var(--petrol)",
  fontSize: 11,
  fontWeight: 600,
  padding: 0,
  textDecoration: "underline",
  cursor: "pointer",
};

// Choix du type de dossier avant la creation : Appel d'offres, Consultation restreinte ou Vente.
// Chaque type ouvre son propre circuit (la consultation et la vente s'enregistrent dans le module Marche).
export default function NouveauDossierPage() {
  const { t } = useLangue();
  const router = useRouter();
  const profil = useProfilActivite();
  const [type, setType] = useState(null);

  useEffect(() => {
    try {
      const q = new URLSearchParams(window.location.search);
      if (q.get("type") === "AO") setType("AO");
    } catch (e) {
      /* ignore */
    }
  }, []);

  const choix = [
    { cle: "AO", titre: "marchesAppelOffresTitle", desc: "nouveauTypeAODesc", accent: "var(--ocre)" },
    { cle: "CONSULTATION", titre: "marchesConsultationRestreinteTitle", desc: "nouveauTypeConsultationDesc", accent: "var(--petrol)", href: "/marches/consultation-restreinte/consultations?nouveau=1&type=CONSULTATION" },
    { cle: "VENTE", titre: "marchesVenteDirecteTitle", desc: "nouveauTypeVenteDesc", accent: "var(--petrol)", href: "/marches/consultation-restreinte/consultations?nouveau=1&type=VENTE" },
  ].filter((c) => (profil === "NEGOCE" ? c.cle === "VENTE" : profil === "MARCHES" ? c.cle !== "VENTE" : true));

  // Profil Negoce : une seule voie possible, on y va directement.
  useEffect(() => {
    if (profil === "NEGOCE") router.replace("/marches/consultation-restreinte/consultations?nouveau=1&type=VENTE");
  }, [profil, router]);

  if (type === "AO") return <FormulaireAppelOffres />;

  return (
    <AppShell title={t("newDossierButton")}>
      <p style={{ fontSize: 12.5, color: "var(--sub)", marginTop: -6, marginBottom: 20 }}>{t("nouveauTypeQuestion")}</p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 16, maxWidth: 900 }}>
        {choix.map((c) => {
          const contenu = (
            <>
              <h2 style={{ fontSize: 16, color: "var(--petrol)", marginBottom: 8 }}>{t(c.titre)}</h2>
              <p style={{ fontSize: 12.5, color: "var(--sub)", lineHeight: 1.5, marginBottom: 14 }}>{t(c.desc)}</p>
              <span style={{ fontSize: 12.5, fontWeight: 700, color: c.accent }}>{t("nouveauTypeCommencer")} →</span>
            </>
          );
          const style = { display: "block", padding: "22px 22px", textDecoration: "none", color: "inherit", borderTop: `3px solid ${c.accent}`, textAlign: "left", cursor: "pointer", font: "inherit" };
          return c.href ? (
            <Link key={c.cle} href={c.href} className="card" style={style}>{contenu}</Link>
          ) : (
            <button key={c.cle} type="button" onClick={() => setType(c.cle)} className="card" style={style}>{contenu}</button>
          );
        })}
      </div>
    </AppShell>
  );
}
